
******************************
*        ChangeLog           *
* steveinfoservices.free.fr  *
*                            *
*                            *
******************************



V5.2)

- Correction Bug  verification si dossier firefox / chrome present.


V5.1)

-Message d'erreur si Backup est selectionné avant 'Backup folder'.


V5.0)

- Lettre sélectionnable dans le menu 
(pour ne pas être obligé à sélectionner le lettre de sauvegarde au lancement, lors de la restauration uniquement)
-Possibilité de sauvegarde sur C directement (même si je ne vois pas trop l'intérêt ! :)



V4.3)

- Supprimer  Win 2003 , Win 2000 , utilisable sur tout Windows
- .ico

V4.2)
- Menu choix lecteur + visible
- Compatible Windows 11

V4.1)
- Ajout du dossier Musique

- Ajout de sauvegarde Chrome et Firefox si présent

V4)
- Sauvegarde du dossier au nom du PC "Backup"
- Compatible W10 et antérieur

- Fonction restaurer dossier